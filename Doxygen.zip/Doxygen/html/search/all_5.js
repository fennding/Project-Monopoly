var searchData=
[
  ['tax_0',['Tax',['../class_classes_1_1_tax.html',1,'Classes']]],
  ['textrenderer_1',['TextRenderer',['../class_classes_1_1_text_renderer.html',1,'Classes']]]
];
